import os
import numpy as np
import soundfile as sf
import matplotlib.pyplot as plt

# Definir la ruta de la carpeta
carpeta_audios = 'audios/'

# Nombres de los archivos
archivo_audio1 = 'audio1.wav'
archivo_audio2 = 'audio2.wav'
archivo_ruido = 'ruido.wav'
archivo_mezclado = 'audio_mezclado.wav'
archivo_beamformed = 'audio_beamformed.wav'  # Archivo para guardar la señal beamformed

# Función para calcular la potencia de una señal
def calcular_potencia(señal):
    return np.mean(np.square(señal))

# Función para realizar la FFT y obtener las frecuencias
def realizar_fft(señal, sr):
    N = len(señal)
    fft_señal = np.fft.fft(señal)
    fft_señal = np.abs(fft_señal[:N // 2])  # Usamos solo la mitad positiva
    freqs = np.fft.fftfreq(N, 1 / sr)[:N // 2]  # Frecuencias asociadas
    return freqs, fft_señal

# Función para aplicar el beamforming basado en la Transformada de Fourier
def beamforming_fft(signales, sr, mic_distances):
    num_mic = len(signales)
    N = len(signales[0])
    freqs = np.fft.fftfreq(N, 1 / sr)[:N // 2]
    speed_of_sound = 343  # Velocidad del sonido en m/s
    
    # Calcula la FFT para cada señal
    fft_signales = [np.fft.fft(sig) for sig in signales]
    
    # Calcula los retardos para cada frecuencia
    delays = np.exp(-2j * np.pi * np.outer(freqs, mic_distances / speed_of_sound))
    
    # Aplica el beamforming en el dominio de la frecuencia
    beamformed_fft = np.mean([fft * delays for fft, delays in zip(fft_signales, delays)], axis=0)
    
    # Inversa FFT para obtener la señal beamformed
    beamformed_signal = np.fft.ifft(beamformed_fft)
    
    return np.real(beamformed_signal)

# Cargar los audios
audio1, sr1 = sf.read(os.path.join(carpeta_audios, archivo_audio1))
audio2, sr2 = sf.read(os.path.join(carpeta_audios, archivo_audio2))
ruido, sr_ruido = sf.read(os.path.join(carpeta_audios, archivo_ruido))

# Asegurarnos de que las frecuencias de muestreo sean las mismas
assert sr1 == sr2 == sr_ruido, "Las frecuencias de muestreo de los audios no coinciden."

# Ajustar la longitud de las señales
min_length = min(len(audio1), len(audio2), len(ruido))
audio1 = audio1[:min_length]
audio2 = audio2[:min_length]
ruido = ruido[:min_length]

# Mezclar las señales de audio 1, audio 2 y ruido
audio_mezclado = audio1 + audio2 + ruido  # Mezcla simple promedio


# Aplicar beamforming a las señales originales (audio1 y audio2)
señales_mezcladas = [audio1, audio2]  # Usamos los audios originales para el beamforming
señal_beamformed = beamforming_fft(señales_mezcladas, sr1, 2)  # Ajustar la distancia entre micrófonos según sea necesario

# Asegurarnos de que la señal beamformed tenga la misma longitud que la original
if len(señal_beamformed) > len(audio1):
    señal_beamformed = señal_beamformed[:len(audio1)]
elif len(señal_beamformed) < len(audio1):
    audio1 = audio1[:len(señal_beamformed)]

# Guardar la señal beamformed en un archivo WAV
sf.write(os.path.join(carpeta_audios, archivo_beamformed), señal_beamformed, sr1)
print(f"Señal beamformed guardada en: {os.path.join(carpeta_audios, archivo_beamformed)}")

# Calcular las potencias
potencia_audio1 = calcular_potencia(audio1)
potencia_audio2 = calcular_potencia(audio2)
potencia_mezclado = calcular_potencia(audio_mezclado)
potencia_ruido = calcular_potencia(ruido)
potencia_señal_beamformed = calcular_potencia(señal_beamformed)

# Calcular el SNR para cada audio con respecto al ruido
snr_audio1 = 10 * np.log10(potencia_audio1 / potencia_ruido)
snr_audio2 = 10 * np.log10(potencia_audio2 / potencia_ruido)
snr_mezclado = 10 * np.log10(potencia_mezclado / potencia_ruido)
snr_beamformed = 10 * np.log10(potencia_señal_beamformed / potencia_ruido)

# Mostrar los resultados
print(f"Potencia de audio1: {potencia_audio1}")
print(f"Potencia de audio2: {potencia_audio2}")
print(f"Potencia de ruido: {potencia_ruido}")
print(f"Potencia de audio mezclado: {potencia_mezclado}")
print(f"Potencia de la señal aislada: {potencia_señal_beamformed}")

print(f"SNR de audio1: {snr_audio1:.2f} dB")
print(f"SNR de audio2: {snr_audio2:.2f} dB")
print(f"SNR de audio mezclado: {snr_mezclado:.2f} dB")
print(f"SNR de la señal aislada: {snr_beamformed:.2f} dB")

# Gráfica de las señales en el dominio del tiempo
plt.figure(figsize=(15, 12))

# Gráfico del audio 1 en el tiempo
plt.subplot(6, 1, 1)
plt.plot(np.arange(len(audio1)) / sr1, audio1, color='blue')
plt.title('Audio 1 - Dominio del Tiempo')
plt.xlabel('Tiempo [s]')
plt.ylabel('Amplitud [v]')

# Gráfico del audio 2 en el tiempo
plt.subplot(6, 1, 2)
plt.plot(np.arange(len(audio2)) / sr2, audio2, color='green')
plt.title('Audio 2 - Dominio del Tiempo')
plt.xlabel('Tiempo [s]')
plt.ylabel('Amplitud [v]')

# Gráfico del audio mezclado en el tiempo
plt.subplot(6, 1, 3)
plt.plot(np.arange(len(audio_mezclado)) / sr1, audio_mezclado, color='purple')
plt.title('Audio Mezclado - Dominio del Tiempo')
plt.xlabel('Tiempo [s]')
plt.ylabel('Amplitud [v]')

# Gráfico del ruido en el tiempo
plt.subplot(6, 1, 4)
plt.plot(np.arange(len(ruido)) / sr_ruido, ruido, color='gray')
plt.title('Ruido - Dominio del Tiempo')
plt.xlabel('Tiempo [s]')
plt.ylabel('Amplitud [v]')

# Gráfico de la señal beamformed en el tiempo
plt.subplot(6, 1, 5)
plt.plot(np.arange(len(señal_beamformed)) / sr1, señal_beamformed, color='red')
plt.title('Señal Beamformed - Dominio del Tiempo')
plt.xlabel('Tiempo [s]')
plt.ylabel('Amplitud [v]')

plt.tight_layout()
plt.show()

# Análisis espectral (FFT) de las señales
plt.figure(figsize=(15, 12))

# Gráfico del espectro del audio 1 en escala semilogarítmica
plt.subplot(3, 1, 1)
freqs_audio1, fft_audio1 = realizar_fft(audio1, sr1)
plt.semilogx(freqs_audio1, fft_audio1, color='blue')
plt.title('Audio 1 - Espectro de Frecuencia (Escala Semilogarítmica)')
plt.xlabel('Frecuencia [Hz]')
plt.ylabel('Espectro de Energia [m2/Hz]')
plt.xlim(20, sr1 // 2)

# Gráfico del espectro del audio 2 en escala semilogarítmica
plt.subplot(3, 1, 2)
freqs_audio2, fft_audio2 = realizar_fft(audio2, sr2)
plt.semilogx(freqs_audio2, fft_audio2, color='green')
plt.title('Audio 2 - Espectro de Frecuencia (Escala Semilogarítmica)')
plt.xlabel('Frecuencia [Hz]')
plt.ylabel('Espectro de Energia [m2/Hz]')
plt.xlim(20, sr2 // 2)

# Gráfico del espectro del ruido en escala semilogarítmica
plt.subplot(3, 1, 3)
freqs_ruido, fft_ruido = realizar_fft(ruido, sr_ruido)
plt.semilogx(freqs_ruido, fft_ruido, color='gray')
plt.title('Ruido - Espectro de Frecuencia (Escala Semilogarítmica)')
plt.xlabel('Frecuencia [Hz]')
plt.ylabel('Espectro de Energia [m2/Hz]')
plt.xlim(20, sr_ruido // 2)

plt.tight_layout()
plt.show()

# Gráfico del espectro del audio mezclado y la señal beamformed
plt.figure(figsize=(15, 10))

# Gráfico del espectro del audio mezclado en escala semilogarítmica
plt.subplot(2, 1, 1)
freqs_mezclado, fft_mezclado = realizar_fft(audio_mezclado, sr1)
plt.semilogx(freqs_mezclado, fft_mezclado, color='purple')
plt.title('Audio Mezclado - Espectro de Frecuencia (Escala Semilogarítmica)')
plt.xlabel('Frecuencia [Hz]')
plt.ylabel('Espectro de Energia [m2/Hz]')
plt.xlim(20, sr1 // 2)

# Gráfico del espectro de la señal beamformed en escala semilogarítmica
plt.subplot(2, 1, 2)
freqs_beamformed, fft_beamformed = realizar_fft(señal_beamformed, sr1)
plt.semilogx(freqs_beamformed, fft_beamformed, color='red')
plt.title('Señal Aislada - Espectro de Frecuencia (Escala Semilogarítmica)')
plt.xlabel('Frecuencia [Hz]')
plt.ylabel('Espectro de Energia [m2/Hz]')
plt.xlim(20, sr1 // 2)

plt.tight_layout()
plt.show()
